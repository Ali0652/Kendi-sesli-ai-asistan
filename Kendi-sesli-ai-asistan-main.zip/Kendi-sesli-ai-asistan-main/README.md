# Kendi-sesli-ai-asistan
Kendi sesli asistanını yapmanın yolu 
